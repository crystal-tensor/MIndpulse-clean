<?php
require_once '../config/database.php';
require_once '../utils/response.php';
require_once '../utils/http_client.php';

// 处理跨域预检请求
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization');
    exit(0);
}

// 路由处理
$requestUri = $_SERVER['REQUEST_URI'];
$path = parse_url($requestUri, PHP_URL_PATH);
$pathParts = explode('/', trim($path, '/'));

// 移除 'api' 前缀
if ($pathParts[0] === 'api') {
    array_shift($pathParts);
}

$endpoint = $pathParts[0] ?? '';

switch ($endpoint) {
    case 'health':
        include 'health.php';
        break;
    case 'chat':
        include 'chat.php';
        break;
    case 'test-connection':
        include 'test-connection.php';
        break;
    case 'extract-variables':
        include 'extract-variables.php';
        break;
    default:
        Response::error('API端点不存在', 404);
}
?>
